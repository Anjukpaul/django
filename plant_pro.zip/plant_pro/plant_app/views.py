from django.shortcuts import render,redirect
from .models import uploadfile

import keras
import tensorflow

import numpy as np
from tensorflow.keras.preprocessing.image import ImageDataGenerator, load_img, img_to_array


classifier= keras.models.load_model("c:\\Users\\AVITA PC\\Desktop\\anju_paul\\models\\plant_model.hdf5")

# Create your views here.
def index(request):
    if request.method == 'POST':
        uploaded_file = request.FILES['file1']
        fn = uploaded_file.name

        uploaded_file_obj = uploadfile(myfile=uploaded_file)
        uploaded_file_obj.save()

        path = "C:\\Users\\AVITA PC\\Desktop\\anju_paul\\for_ml_project\\plant_pro\\media\\media\\"+fn
        new_img = load_img(path, target_size=(224, 224))
        img = img_to_array(new_img)

        li = ['Alpinia Galanga', 'Amaranthus Viridis', 'Artocarpus Heterophyllus', 'Azadirachta Indica', 'Basella Alba', 'Brassica Juncea', 'Carissa Carandas', 'Citrus Limon', 'Ficus Auriculata', 'Ficus Religiosa', 'Hibiscus Rosa-sinensis', 'Jasminum', 'Mangifera Indica', 'Mentha', 'Moringa Oleifera', 'Muntingia Calabura', 'Murraya Koenigii', 'Nerium Oleander', 'Nyctanthes Arbor-tristis', 'Ocimum Tenuiflorum', 'Piper Betle', 'Plectranthus Amboinicus', 'Pongamia Pinnata', 'Psidium Guajava', 'Punica Granatum', 'Santalum Album', 'Syzygium Cumini', 'Syzygium Jambos', 'Tabernaemontana Divaricata', 'Trigonella Foenum-graecum']
        img = np.expand_dims(img, axis=0)
        img = img/255
        prediction = classifier.predict(img)
        d = prediction.flatten()
        j = d.max()
        print('value of pic ',j)
        for index,item in enumerate(d):
            if item == j:
                class_name = li[index]
                pk=class_name
                # print(pk)
        return render(request,'index.html',{'class_name':class_name})        
    else:
     return render(request,'index.html')