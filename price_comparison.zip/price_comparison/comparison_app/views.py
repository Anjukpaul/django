from django.shortcuts import render,redirect
from . models import reg,product,Feedback,list,cart,procedpay,whishlist

import smtplib


import razorpay #import this
from django.conf import settings
from django.http import JsonResponse #import this
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt #import this
from django.http import HttpResponseBadRequest #import this
razorpay_client = razorpay.Client(
    auth=(settings.RAZOR_KEY_ID, settings.RAZOR_KEY_SECRET))

import requests
import json
url = "https://pricer.p.rapidapi.com/str"

# Create your views here.
def index(request):
    return render(request,'index.html')

def home(request):
    return render(request,'home.html')

def register(request):
   if request.method =='POST':
      fname = request.POST.get('rfname')
      email = request.POST.get('remail')
      phone = request.POST.get('rcontact')
      uname = request.POST.get('runame')
      passw = request.POST.get('rpass')
      reg(fullname=fname,email=email,contact=phone,username=uname,password=passw).save()
      return render(request,'login.html')
   else:
      return render(request,'register.html')

def login(request):
   if request.method=='POST':
      uname = request.POST.get('runame')
      passw = request.POST.get('rpass')
      cr = reg.objects.filter(username=uname,password=passw)
      if cr:
         details = reg.objects.get(username=uname, password = passw)
         username = details.username
         e = details.email
         request.session['cs']=username
         request.session['em']=e

         return render(request,'home.html')
      else:
         message="Invalid Username Or Password"
         return render(request,'login.html',{'me':message})
   else: 
      return render(request,'login.html')

def profile(request):
   c=request.session['cs']
   cr=reg.objects.get(username=c)
   pfname=cr.fullname
   pemail=cr.email
   pcontact=cr.contact
   usrnm=cr.username
   pswd=cr.password
  
   return render(request,'profile.html',{'name':pfname,'email':pemail,'contact':pcontact,'usrnm':usrnm,'pswd':pswd})

def pro_list(request):
   data= product.objects.all()
   return render(request,'pro_list.html',{'data':data})

def profile_update(request):
   c=request.session['cs']
   cr=reg.objects.get(username=c)
   pfname=cr.fullname
   pemail=cr.email
   pcontact=cr.contact
   usrnm=cr.username
   pswd=cr.password
   return render(request,'profile_update.html',{'name':pfname,'email':pemail,'contact':pcontact,'usrnm':usrnm,'pswd':pswd})


def pro_updated(request):
   c=request.session['cs']
   if request.method =='POST':
      fname = request.POST.get('rfname')
      email = request.POST.get('remail')
      phone = request.POST.get('rcontact')
      uname = request.POST.get('runame')
      passw = request.POST.get('rpass')

      da=reg.objects.get(username=c)
      da.fullname=fname
      da.email=email
      da.contact=phone
      da.username=uname
      da.password=passw
      da.save()
      return redirect('/profile/')
   else:
      return render(request,'profile_update.html')
   
def feedback(request):
   if request.method =='POST':
      name = request.POST.get('usname')
      ph = request.POST.get('ucontact')
      email = request.POST.get('uemail')
      feed = request.POST.get('feed')
      Feedback(username=name,phone=ph,email=email,feed=feed).save()
      return render(request,'home.html')
   else:
      return render(request,'feedback.html')
   

   

def productt(request):
   if request.method=='POST':
      sr=request.POST.get('cs')
      querystring = {"q":sr}

      headers = {
         "X-RapidAPI-Key": "031ecfb78cmshefa2eaa4a1fcd5bp1c4843jsn22a0d9ce6f64",
         "X-RapidAPI-Host": "pricer.p.rapidapi.com"
      }

      response = requests.get(url, headers=headers, params=querystring)

      print(response.json())   

      result=response.json()
      # print(result)

      li=[]

      for i in range(1,12):
        # Extract the price as a string
         price_with_dollar = result[i]['price']
            
            # Remove the "$" sign and convert to float
         price_without_dollar = float(price_with_dollar.replace('$', '').replace(',', ''))
         
         exchange_rate = 75.0  # Replace with the actual exchange rate
    
    # Calculate the price in INR
         inr_price = price_without_dollar*exchange_rate 

         dic = {
            "image":result[i]['img'],
            'title':result[i]['title'],
            'price':inr_price,
            'shop':result[i]['shop']

  
         }
         
         li.append(dic)
      sorted_li = sorted(li, key=lambda x: x['price'])

        # Save the sorted list to the model
      for item in sorted_li:
            list_item = list(
                image=item['image'],
                product_name=item['title'],
                price=item['price'],
                shop=item['shop']
            )
            list_item.save()
      request.session['prod']=li

      


      print('title 2 is ',result[1]['title'])
      print('price 2 is ',result[1]['price'])

      li2=list.objects.all()
      return render(request,'listpricecom.html',{'lis':li2})
   else:
      return render(request,'home.html')
   


def cartt(request,id):
   print("hii")
   cr=list.objects.get(id=id)
   print("hii")
   im=cr.image
   pn=cr.product_name
   pr=cr.price
   
   sh=cr.shop
   print("hii")
   c=request.session['cs']
   cr=reg.objects.get(username=c)
   print("hii")
   n=cr.fullname
   e=cr.email
   print("hii")
   cart(username1=n,email=e,image=im,product_name=pn,price=pr,shop=sh).save()
   print("hii")
   dl=list.objects.all()
   dl.delete()
   return render(request,'home.html')
   


def cartlist(request):
   c=request.session['cs']
   e=request.session['em']
   cr=cart.objects.filter(username1=c,email=e)
   # li = []
   # for i in cr:
   #    dictt = {
   #         'image':i.image,
   #         'product_name':i.product_name,
   #         'price':i.price,
   #         'shop':i.shop
   #       }
   #    li.append(dictt)
   #    print(li)
   return render(request,'cart.html',{'li':cr})
   # else:
      # return render(request,'productcom.html')

def rmcart(request,id):
   cr=cart.objects.get(id=id)
   cr.delete()
   return render(request,'home.html')

def paycarti(request,id):
   cr=cart.objects.get(id=id)
   u=cr.username1
   e=cr.email
   i=cr.image
   p=cr.product_name
   pr=cr.price
   s=cr.shop
   procedpay(username=u,email=e,image=i,product_name=p,price=pr,shop=s).save()
   cr.delete()
   pr1=int(pr)
   am=int(pr1*100)
   print('amount is',str(am))
   currency = 'INR'

   razorpay_order = razorpay_client.order.create(dict(amount=am,
                                                       currency=currency,
                                                       payment_capture='0'))
 
    # order id of newly created order.
   razorpay_order_id = razorpay_order['id']
   callback_url = 'paymenthandler/'

   # we need to pass these details to frontend.
   context = {}
   context['razorpay_order_id'] = razorpay_order_id
   context['razorpay_merchant_key'] = settings.RAZOR_KEY_ID
   context['razorpay_amount'] = pr
   context['currency'] = currency
   context['callback_url'] = callback_url
 
   return render(request, 'payment.html', context=context)
 
@csrf_exempt
def paymenthandler(request):
 
    # only accept POST request.
    if request.method == "POST":
        try:
           
            # get the required parameters from post request.
            payment_id = request.POST.get('razorpay_payment_id', '')
            razorpay_order_id = request.POST.get('razorpay_order_id', '')
            signature = request.POST.get('razorpay_signature', '')
            params_dict = {
                'razorpay_order_id': razorpay_order_id,
                'razorpay_payment_id': payment_id,
                'razorpay_signature': signature
            }
 
            # verify the payment signature.
            result = razorpay_client.utility.verify_payment_signature(
                params_dict)
            if result is not None:
                amount = 20000  # Rs. 200
                try:
 
                    # capture the payemt
                    razorpay_client.payment.capture(payment_id, amount)
 
                    # render success page on successful caputre of payment
                    return render(request, 'payment_success.html')
                except:
 
                    # if there is an error while capturing payment.
                    return render(request, 'payment_fail.html')
            else:
 
                # if signature verification fails.
                return render(request, 'payment_fail.html')
        except:
 
            # if we don't find the required parameters in POST data
            return HttpResponseBadRequest()
    else:
       # if other than POST request is made.
        return HttpResponseBadRequest()

def whish(request,id):
   print("hii")
   cr=list.objects.get(id=id)
   print("hii")
   im=cr.image
   pn=cr.product_name
   pr=cr.price
   
   sh=cr.shop
   print("hii")
   c=request.session['cs']
   cr=reg.objects.get(username=c)
   print("hii")
   n=cr.fullname
   e=cr.email
   print("hii")
   whishlist(username1=n,email=e,image=im,product_name=pn,price=pr,shop=sh).save()
   print("hii")
   dl=list.objects.all()
   dl.delete()
   return render(request,'home.html')   

def whishlistt(request):
   c=request.session['cs']
   e=request.session['em']
   cr=whishlist.objects.filter(username1=c,email=e)
   # li = []
   # for i in cr:
   #    dictt = {
   #         'image':i.image,
   #         'product_name':i.product_name,
   #         'price':i.price,
   #         'shop':i.shop
   #       }
   #    li.append(dictt)
   #    print(li)
   return render(request,'whishlist.html',{'li':cr})

def rmwhish(request,id):
   cr=whishlist.objects.get(id=id)
   cr.delete()
   return render(request,'home.html')  

def adlogin(request):  # admin side
   if request.method=='POST':
      uname = request.POST.get('runame')
      passw = request.POST.get('rpass')
      u = 'admin'
      p = 'admin'
      if uname==u:
         if passw==p:
          return render(request,'adhome.html')
         
   return render(request,"adlogin.html")

def adhome(request):
   
   return render(request,"adhome.html")

def adpay(request):
   cr=procedpay.objects.all()
   return render(request,"adpay.html",{'li':cr})

def rpay(request,id):
   cr=procedpay.objects.get(id=id)
   cr.delete()
   return render(request,'adhome.html')

def adcart(request):
   cr=cart.objects.all()
   return render(request,"adcart.html",{'li':cr})

def rmcart(request,id):
   cr=cart.objects.get(id=id)
   cr.delete()
   return render(request,'adhome.html')

def adfeedbacks(request):
   cr=Feedback.objects.all()
   return render(request,"adfeedbacks.html",{'li':cr})

def rmadfeedbacks(request,id):
   cr=Feedback.objects.get(id=id)
   cr.delete()
   return render(request,"adfeedbacks.html")

def adwhishlist(request):
   cr=whishlist.objects.all()
   return render(request,"adwhishlist.html",{'li':cr})

def rmadwhishlist(request,id):
   cr=whishlist.objects.get(id=id)
   cr.delete()
   return render(request,'adhome.html')

def aduser(request):
   cr=reg.objects.all()
   return render(request,"aduser.html",{'li':cr})

def rmaduser(request,id):
   cr=reg.objects.get(id=id)
   cr.delete()
   return render(request,'adhome.html')
