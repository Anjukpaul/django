from django.db import models

# Create your models here.
class reg(models.Model):
    fullname=models.CharField(max_length=20)
    email=models.EmailField()
    contact=models.IntegerField()
    username=models.CharField(max_length=20)
    password=models.CharField(max_length=20)

class product(models.Model):
    product_name=models.CharField(max_length=50)
    category=models.CharField(max_length=20)
    price=models.IntegerField()
    image=models.ImageField()
    shop=models.CharField(max_length=100)

class Feedback(models.Model):        
    username=models.CharField(max_length=20)
    phone=models.IntegerField()
    email=models.EmailField()  
    feed=models.TextField()  

class list(models.Model):
    image=models.CharField(max_length=200)
    product_name=models.CharField(max_length=100)
    price=models.IntegerField()
    shop=models.CharField(max_length=100)

class cart(models.Model):
    username1=models.CharField(max_length=20)
    email=models.EmailField()
    image=models.ImageField()
    product_name=models.CharField(max_length=100)
    price=models.IntegerField()
    shop=models.CharField(max_length=100)

class procedpay(models.Model):
    username=models.CharField(max_length=20)
    email=models.EmailField()
    image=models.ImageField()
    product_name=models.CharField(max_length=100)
    price=models.IntegerField()
    shop=models.CharField(max_length=100)

class whishlist(models.Model):
    username1=models.CharField(max_length=20)
    email=models.EmailField()
    image=models.ImageField()
    product_name=models.CharField(max_length=100)
    price=models.IntegerField()
    shop=models.CharField(max_length=100)



#