from django.contrib import admin
from.models import reg,product,Feedback,list,cart,procedpay,whishlist

# Register your models here.
admin.site.register(reg)
admin.site.register(product)
admin.site.register(Feedback)
admin.site.register(list)
admin.site.register(cart)
admin.site.register(procedpay)
admin.site.register(whishlist)