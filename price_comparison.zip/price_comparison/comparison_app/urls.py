"""price_comparison URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from . import views


urlpatterns = [
    path('',views.index,name='index'),
    path('index/',views.index,name='index'),
    path('register/',views.register,name='register'),
    path('login/',views.login,name='login'),
    path('home/',views.home,name='home'),
    path('profile/',views.profile,name='profile'),
    path('pro_list/',views.pro_list,name='pro_list'),
    path('profile_update/',views.profile_update,name='profile_update'),
    path('pro_updated/',views.pro_updated,name='pro_updated'),
    path('feedback/',views.feedback,name='feedback'),
    path('productcom/',views.productt,name='product'),
    path('cartt/<int:id>', views.cartt, name='cartt'),
    path('cartlist/',views.cartlist,name="cartlist"),
    path('rmcart/<int:id>',views.rmcart,name='rmcart'),
    path('paycarti/<int:id>',views.paycarti,name='paycarti'),
    path('whish/<int:id>',views.whish,name='whish'),
    path('whishlist/',views.whishlistt,name='whishlist'),
    path('rmwhish/',views.rmwhish,name='rmwhish'),
   
    path("adlogin/",views.adlogin,name="adlogin"),
    path('adhome/',views.adhome,name='adhome'),
    path('adpay/',views.adpay,name='adpay'),
    path('rpay/<int:id>',views.rpay,name='rpay'),
    path('adcart/',views.adcart,name='adcart'),
    path('rmcart/<int:id>',views.rmcart,name='rmcart'),
    path('adfeedbacks/',views.adfeedbacks,name='adfeedbacks'),
    path('rmadfeedbacks/<int:id>',views.adfeedbacks,name='adfeedbacks'),
    path("adwhishlist/",views.adwhishlist,name='adwhishlist'),
    path('rmadwhishlist/<int:id>',views.rmadwhishlist,name='rmadwhishlist'),
    path("aduser/",views.aduser,name='aduser'),
    path("rmaduser/<int:id>",views.rmaduser,name='rmaduser'),
]

