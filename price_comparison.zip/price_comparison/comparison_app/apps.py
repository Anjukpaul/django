from django.apps import AppConfig


class ComparisonAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'comparison_app'
