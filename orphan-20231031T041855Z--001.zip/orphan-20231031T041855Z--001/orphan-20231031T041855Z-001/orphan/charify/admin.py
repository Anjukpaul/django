from django.contrib import admin
from . models import user,orphanage,orphansdetail,needdonation,add2cart,procedpay,adoptionnn

# Register your models here.
admin.site.register(user)
admin.site.register(orphanage)
admin.site.register(orphansdetail)
admin.site.register(needdonation)
admin.site.register(add2cart)
admin.site.register(procedpay)
admin.site.register(adoptionnn)