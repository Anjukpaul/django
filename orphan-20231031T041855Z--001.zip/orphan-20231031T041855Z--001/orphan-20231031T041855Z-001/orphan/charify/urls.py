from django.urls import path
from . import views

urlpatterns=[
    path("index/",views.index,name="index"),

    path("about/",views.about,name="about"),
    path("contact/",views.contact,name="contact"),
    path("reference/",views.reference,name="reference"),

    path("orphpic/",views.orphpic,name="orphpic"),
    
    path("delete_record/<int:id>",views.delete_record,name="delete_record"),
    
    path('regorph/',views.regorph,name='regorph'),
    path('loginorph/',views.loginorph,name='loginorph'),
    path('orphanage/',views.orphanage1,name='orphanage'),
    path('orphprofile/',views.orprofile,name='orphprofile'),
    path('updatepro/',views.updatepro,name='updatepro'),
    path('donationform/',views.donationform,name='donationform'),
    path('orphhome/',views.orphhome,name='orphhome'),
    path('bankdorph/',views.bankdorph,name='bankdorph'),
    path('orphans/',views.orphans,name='orphans'),
    path('listorphans/',views.listorphans,name='listorphans'),
    path('delete_orphan/<int:id>/', views.delete_orphan, name='delete_orphan'),
    path('orphdonatlist/',views.orphdonatlist,name='orphdonatlist'),
    path('delete_orphan1/<int:id>/', views.delete_orphan1, name='delete_orphan1'),
    path('adoption/',views.adoption,name='adoption'),
    path('accept/<int:id>',views.accept,name='accept'),
    path('denied/<int:id>', views.denied, name='denied'),    


    path("register/",views.register,name="register"),
    path("login/",views.login,name="login"),
    path('don/',views.don,name='don'),
    path("profile/",views.profile,name="profile"),
    path('donationrequ/',views.donationrequ,name='donationrequ'),
    path('cart/<int:id>/',views.cart,name='cart'),
    path('removeallcart/',views.removeallcart,name='removeallcart'),
    path('orphansdona/',views.orphansdona,name='orphansdona'),
    path('ad_reuest/<int:id>',views.requestt,name='reuest'),
    path('add_to_cart/',views.add_to_cart,name='add_to_cart'),
    path('listcart/',views.listcart,name='listcart.html'),
    path('removecartitem/<int:id>',views.removecartitem,name='removecartitem'),
    path('proced/',views.proced,name='proced'),
    path('paymenthandler/', views.paymenthandler, name='paymenthandler'),

    path("adlogin/",views.adlogin,name='adlogin'),
    path("adhome/",views.adhome,name='adhome'),
    path("addoners/",views.addoners,name='addoners'),
    path("rmaddoners/<int:id>",views.rmaddoners,name='rmaddoners'),
    path("adorphanages/",views.adorphanages,name='adorphanages'),
    path("rmadorphanages/<int:id>",views.rmadorphanages,name='rmadorphanages'),
    path('update_status/<int:id>',views.update_status, name='update_status'),
    path('orphans_list/', views.orphans_list, name='orphans_list'),
    path('delete_orphan/<int:id>', views.delete_orphan, name='delete_orphan'),
    path('adneeds/', views.adneeds, name='adneeds'),
    path('rmadneeds/<int:id>', views.rmadneeds, name='rmadneeds'),
    
]