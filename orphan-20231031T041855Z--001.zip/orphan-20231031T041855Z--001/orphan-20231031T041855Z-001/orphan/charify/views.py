from django.shortcuts import render,redirect
from . models import user,orphanage,needdonation,orphansdetail,add2cart,procedpay,adoptionnn
# Create your views here.


import smtplib
import razorpay #import this
from django.conf import settings
from django.http import JsonResponse #import this
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt #import this
from django.http import HttpResponseBadRequest #import this
razorpay_client = razorpay.Client(
    auth=(settings.RAZOR_KEY_ID, settings.RAZOR_KEY_SECRET))

def index(request):
    return render(request,'index.html')
def about(request):
    return render(request,'about.html')
def contact(request):
    return render(request,'contact.html')
def reference(request):
    return render(request,'blog.html')


def orphpic(request):
    cr=orphanage.objects.all()
    return render(request,'orphpic.html',{'orphanage':cr})


def profile(request):
    u=request.session['cs']
    cr=user.objects.get(username=u)
    vname=cr.fullname
    vgender=cr.age
    vaddress=cr.address
    vcontact=cr.contact
    vemail=cr.email
    vusername=cr.username
    return render(request,'profile.html',{'pname':vname,'pgender':vgender,'paddress':vaddress,'pcontact':vcontact,'pemail':vemail,'pusername':vusername})

def delete_record(request,id):
    data=orphanage.objects.get(id=id)
    data.delete()
    return render(request,'index.html')











def register(request):
    if request.method=='POST':
        fname=request.POST.get('rname')
        fage=request.POST.get('rage') 
        fgender=request.POST.get('rgender')
        faddress=request.POST.get('raddress')
        fcontact=request.POST.get('rcontact')
        femail=request.POST.get('remail')
        fusername=request.POST.get('runame')
        fpassword=request.POST.get('rpswd')

        user(fullname=fname,age=fage,gender=fgender,address=faddress,contact=fcontact,email=femail,username=fusername,password=fpassword).save()
        return render(request,'login.html')
    else:
        return render(request,'register.html')
    

def login(request):
    if request.method=="POST":
        a=request.POST.get('runame')
        b=request.POST.get('rpass')
        c=user.objects.filter(fullname=a,password=b)
        if c:
            u=user.objects.get(fullname=a,password=b)
            d=u.fullname
            print(d)
            e=u.email

            request.session['runame']=d
            request.session['email']=e
            return render(request,'don.html')
        else:
            return render(request,'login.html')
    else:
        return render(request,'login.html')
    
def don(request):
    return render(request,'don.html')
    
def profile(request):
    u=request.session['runame']
    # c=request.session['pswd']
    cr=user.objects.get(fullname=u)
    vname=cr.fullname
    vgender=cr.age
    vaddress=cr.address
    vcontact=cr.contact
    vemail=cr.email
    vusername=cr.username
    return render(request,'profile.html',{'a':vname,'b':vgender,'c':vaddress,'d':vcontact,'e':vemail,'f':vusername})

def donationrequ(request):
    g=needdonation.objects.all()
    return render(request,'donationrequ.html',{"g":g})
    
def cart(request,id):
    dt=needdonation.objects.get(id=id)
    id=dt.id
    a=dt.orphanage_id
    b=dt.contact
    c=dt.category
    d=dt.list_item
    e=dt.quantity
    f=dt.price
    g=dt.upi_id
    return render(request,'addcart.html',{'a':a,'b':b,'c':c,'d':d,'e':e,'f':f,'g':g})

def orphansdona(request):
    g=orphansdetail.objects.all()
    return render(request,'orphansdona.html',{"g2":g})

def requestt(request,id):
    orphan = orphansdetail.objects.get(id=id)
    nn=orphan.fullname
    ag=orphan.age
    iidor=orphan.orphanage_id
    gn=orphan.gender
    u=request.session['runame']
    cr=user.objects.get(fullname=u)
    vname=cr.fullname
    vcontact=cr.contact
    vemail=cr.email
    adoptionnn(or_name=nn,or_age=ag,orphanage_id=iidor,or_gender=gn,u_name=vname,u_contact=vcontact,u_email=vemail).save()
    return render(request,'don.html')


def add_to_cart(request):
    if request.method=='POST':
     a=request.POST.get('n')
     b=request.POST.get('c')
     c=request.POST.get('cry')
     d=request.POST.get('it')
     rq=request.POST.get('rr')
     e=request.POST.get('pr')
     f=request.POST.get('q')

     h=int(e)
     j=int(f)
     monunt=int(h*j)
    #  print(monunt)
     u=request.session['runame']
     cr=user.objects.get(fullname=u)
     vname=cr.fullname
     vage=cr.age
     vgn=cr.gender
     vaddress=cr.address
     vcontact=cr.contact
     vemail=cr.email
     add2cart(orphanage_id=a,contact=b,category=c,list_item=d,quantity=rq,price=e,donatedquantity=f,amount=monunt,fullname=vname,age=vage,gender=vgn,address=vaddress,contact1=vcontact,email=vemail).save()
     return render(request,"donationrequ.html")
    else:
     return render(request,'donationrequ.html')
    

def listcart(request):
    u=request.session['runame']
    e=request.session['email']
    cr=add2cart.objects.filter(fullname=u,email=e)
    cart_list = []
    for i in cr:
        orphan_dict = {
             
            'orphanage_id': i.orphanage_id,
            
            "contact":i.contact,
            'category':i.category,
            'list_item':i.list_item,
            'quantity':i.quantity,
            'price':i.price,
            'donatedquantity':i.donatedquantity,
            'amount':i.amount,
            'id': i.id,

        }
        cart_list.append(orphan_dict)
    return render(request,'listcart.html',{'cl': cart_list})

def removecartitem(request,id):
        if id is not None:
         try:
            orphan = add2cart.objects.get(id=id)
            
            orphan.delete()
            # Redirect to the listorphans page or another appropriate page.
         except add2cart.DoesNotExist:
            # Handle the case where the orphan with the given ID doesn't exist.
            raise Http404("Orphan not found")
        return render(request,'listcart.html')

def removeallcart(request):
    u = request.session['runame']
    e = request.session['email']
    item = add2cart.objects.filter(fullname=u,email=e)
    
    # for  in cart_items:
    item.delete()

    return render(request,'donationrequ.html')

def proced(request):
    u=request.session['runame']
    e=request.session['email']
    cr=add2cart.objects.filter(fullname=u,email=e)
    totalprice = 0
    for i in cr:
        procedpay(orphanage_id=i.orphanage_id,contact=i.contact,category=i.category,list_item=i.list_item,quantity=i.quantity,price=i.price,amount=i.amount,fullname=i.fullname,age=i.age,gender=i.gender,address=i.address,contact1=i.contact1,email=i.email).save()
        totalprice=int(totalprice+i.amount)
        i.delete()
    amount=int(totalprice)
    #amount=200
    print('amount is',str(amount))
    currency = 'INR'
    #amount = 20000  # Rs. 200

    # Create a Razorpay Order
    razorpay_order = razorpay_client.order.create(dict(amount=amount,
                                                       currency=currency,
                                                       payment_capture='0'))
 
    # order id of newly created order.
    razorpay_order_id = razorpay_order['id']
    callback_url = 'paymenthandler/'
 
    # we need to pass these details to frontend.
    context = {}
    context['razorpay_order_id'] = razorpay_order_id
    context['razorpay_merchant_key'] = settings.RAZOR_KEY_ID
    context['razorpay_amount'] = amount
    context['currency'] = currency
    context['callback_url'] = callback_url
 
    return render(request, 'payment.html', context=context)
 
@csrf_exempt
def paymenthandler(request):
 
    # only accept POST request.
    if request.method == "POST":
        try:
           
            # get the required parameters from post request.
            payment_id = request.POST.get('razorpay_payment_id', '')
            razorpay_order_id = request.POST.get('razorpay_order_id', '')
            signature = request.POST.get('razorpay_signature', '')
            params_dict = {
                'razorpay_order_id': razorpay_order_id,
                'razorpay_payment_id': payment_id,
                'razorpay_signature': signature
            }
 
            # verify the payment signature.
            result = razorpay_client.utility.verify_payment_signature(
                params_dict)
            if result is not None:
                amount = 20000  # Rs. 200
                try:
 
                    # capture the payemt
                    razorpay_client.payment.capture(payment_id, amount)
 
                    # render success page on successful caputre of payment
                    return render(request, 'payment_success.html')
                except:
 
                    # if there is an error while capturing payment.
                    return render(request, 'payment_fail.html')
            else:
 
                # if signature verification fails.
                return render(request, 'payment_fail.html')
        except:
 
            # if we don't find the required parameters in POST data
            return HttpResponseBadRequest()
    else:
       # if other than POST request is made.
        return HttpResponseBadRequest()

   
























    
def regorph(request):
    if request.method=='POST':
        Orphanage_id1=request.POST.get('oid')
        Orphanagename=request.POST.get('owname')
        Ownername=request.POST.get('oname')
        Description=request.POST.get('Description')
        Contact=request.POST.get('ocontact')
        Email=request.POST.get('oemail')
        Website=request.POST.get("website")
        Category=request.POST.get("Category")
        bankname=request.POST.get('bn')
        bankbranch=request.POST.get('bb')
        accno_ifsc=request.POST.get('bi')
        Address=request.POST.get("oaddress" )

        Year=request.POST.get("year")
        password=request.POST.get('opswd')
        Status='waiting'
        
        s = smtplib.SMTP('smtp.gmail.com', 587)
        s.starttls()
        s.login("nefsal003@gmail.com", "htxalvzrrkxupspv")
    
        orphanage(orphanage_id=Orphanage_id1,orphanage_name=Orphanagename,owner_name=Ownername,description=Description,contact=Contact,email=Email,website=Website,category=Category,bank_name=bankname,bank_branch=bankbranch,accno_ifsc=accno_ifsc,address=Address,year=Year,password=password,status=Status).save()
        message = f"Congrates!!!your registration has been completed successfully {password}"
        s.sendmail("nefsal003@gmail.com", Email, message)
        s.quit()

        return render(request,"index.html")
    else:
        return render(request,"regorph.html")

def loginorph(request):
    if request.method=="POST":
        a=request.POST.get('runame')
        b=request.POST.get('pswd')
        c=orphanage.objects.filter(orphanage_id=a,password=b)
        if c:
         details = orphanage.objects.get(orphanage_id=a,password=b)
         d = details.orphanage_id
         request.session['df']=d
         return render(request,"orphhome.html")  
        else:
         return render(request,"loginorph.html")
    else:
     return render(request,"loginorph.html")

def orphanage1(request):
    return render(request,'orphanage.html')

def orprofile(request):
    hj=request.session['df']
    cr = orphanage.objects.get(orphanage_id=hj)
    id=cr.id
    print(id)
    a=cr.orphanage_id
    b=cr.orphanage_name
    c=cr.owner_name
    d=cr.description
    e=cr.contact
    f=cr.email
    g=cr.website
    h=cr.category
    i=cr.bank_name
    j=cr.bank_branch
    k=cr.accno_ifsc
    l=cr.address
    o=cr.year
    p=cr.image
    q=cr.status
    return render(request,'orphprofile.html',{'id':id,'a':a,'b':b,'c':c,'d':d,'e':e,'f':f,'g':g,'h':h,'i':i,'j':j,'k':k,'l':l,'o':o,'p':p,'q':q})

def updatepro(request):
    if request.method=='POST':
     
     id=request.POST.get('id')
     Orphanage_id1=request.POST.get('na')
     Orphanagename=request.POST.get('n')
     Ownername=request.POST.get('on')
     Description=request.POST.get('d')
     Contact=request.POST.get('c')
     Email=request.POST.get('e')
     Website=request.POST.get("wb")
     Category=request.POST.get("cr")
     bankname=request.POST.get('bn')
     bankbranch=request.POST.get('bb')
     accno_ifsc=request.POST.get('ai')
     Address=request.POST.get("ad" )
     uploaded_file = request.FILES['file1']
     Year=request.POST.get("yr")
     password=request.POST.get('opswd')
     
     dt=orphanage.objects.get(id=id)

     dt.orphanage_id=Orphanage_id1
     
     dt.orphanage_name=Orphanagename
     dt.owner_name=Ownername
     dt.description=Description
     dt.contact=Contact
     dt.email=Email
     dt.website=Website
     dt.category=Category
     dt.bank_name=bankname
     dt.bank_branch=bankbranch
     dt.accno_ifsc=accno_ifsc
     dt.address=Address
     dt.year=Year
     dt.image=uploaded_file
     dt.password=password
     dt.save()
     return render(request,'orphhome.html')

def donationform(request):
    hj=request.session['df']
    cr = orphanage.objects.get(orphanage_id=hj)
    a=cr.orphanage_id
    i=cr.contact
    if request.method=="POST":
        b=a
        c = request.POST.get("cry")
        d = request.POST.get("oname")
        e = request.POST.get("bn")
        f = request.POST.get("ocontact")
        g= request.POST.get("mn")
        needdonation(orphanage_id=b,category=c,list_item=d,quantity=e,price=f, upi_id=g).save()
        return render(request,'orphhome.html')
    else:
      return render(request,'donationform_orph.html',{'a':a,'i':i})
    

def orphhome(request):
    return render(request,'orphhome.html')

def bankdorph(request):
    hj=request.session['df']
    cr = orphanage.objects.get(orphanage_id=hj)
    i=cr.bank_name
    j=cr.bank_branch
    k=cr.accno_ifsc
    return render(request,'bankdorph.html',{'i':i,'j':j,'k':k})

def orphans(request):
    hj=request.session['df']
    cr = orphanage.objects.get(orphanage_id=hj)
    a=cr.orphanage_id
    i=cr.contact
    if request.method=="POST":
        b=a
        c = request.POST.get("name")
        d = request.POST.get("oname")
        uploaded_file = request.FILES['file1']
        
        f = request.POST.get("ocontact")
        g = request.POST.get("rgender")
        h = request.POST.get("bgr")
        orphansdetail(fullname=c,orphanage_id=b,id_number=d,image=uploaded_file,age=f,gender=g,blood_group=h).save()
        return render(request,'orphhome.html')
    else:
     return render(request,'orphans.html',{'a':a,'i':i})
    
# def listorphans(request):
#         hj=request.session['df']
#         cr = orphansdetail.objects.filter(orphanage_id=hj)
#         # a=cr.orphanage_id

#         return render(request,'listorphans.html',{'a':cr})

def listorphans(request):
    hj = request.session['df']
    orphans = orphansdetail.objects.filter(orphanage_id=hj)
    orphan_list = []
    for orphan in orphans:
        orphan_dict = {
            'orphanage_id': orphan.orphanage_id,
            "contact":orphan.contact,
            'name': orphan.fullname,
            'id_number': orphan.id_number,
            'image': orphan.image,
            'age': orphan.age,
            'gender': orphan.gender,
            'blood_group': orphan.blood_group,
            'id': orphan.id,
        }
        orphan_list.append(orphan_dict)
    return render(request, 'listorphans.html', {'orphans': orphan_list})

from django.http import Http404

def delete_orphan(request, id):
    if id is not None:
        try:
            orphan = orphansdetail.objects.get(id=id)
            orphan.delete()
            # Redirect to the listorphans page or another appropriate page.
        except orphansdetail.DoesNotExist:
            # Handle the case where the orphan with the given ID doesn't exist.
            raise Http404("Orphan not found")
    return render(request, 'listorphans.html')
        

def orphdonatlist(request):
    hj = request.session['df']
    donate = needdonation.objects.filter(orphanage_id=hj)
    orphan_list1 = []
    for i in donate:
        orphan_dict1 = {
            "orphanage_id":i.orphanage_id,
            "category":i.category,
            "contact":i.contact,
            "list_item":i.list_item,
            "quantity":i.quantity,
            'price':i.price,
            "upi_id":i.upi_id,
            'id': i.id,
        }
        orphan_list1.append(orphan_dict1)
    return render(request,'orphdonatlist.html', {'orphans11': orphan_list1})

def delete_orphan1(request, id):
    if id is not None:
        try:
            orphan = needdonation.objects.get(id=id)
            orphan.delete()
            # Redirect to the listorphans page or another appropriate page.
        except orphansdetail.DoesNotExist:
            # Handle the case where the orphan with the given ID doesn't exist.
            raise Http404("Orphan not found")
    return render(request, 'orphdonatlist.html')
def adoption(request):
    hj=request.session['df']
    cr = adoptionnn.objects.filter(orphanage_id=hj)
    li=[]
    for i in cr:
        dic = {
           'a':i.or_name,
           'b':i.or_age,
           'c':i.orphanage_id,
           'd':i.or_gender,
           'e':i.u_name,
           'f':i.u_contact,
           'g':i.u_email,
           'id':i.id
           
        }
        li.append(dic)
    return render(request,'Adoption.html',{'data':li})

def accept(request,id):
     r='Request Accept'
     cr = adoptionnn.objects.get(id=id)
     print(id)
     cr.status=r
     e=cr.u_email
     cr.save()
     s = smtplib.SMTP('smtp.gmail.com', 587)
     s.starttls()
     s.login("nefsal003@gmail.com", "htxalvzrrkxupspv")
     message = f' Request Accept  successfully'
     s.sendmail("nefsal003@gmail.com", e, message)
     s.quit()
     print(r)
    
     return render(request,'Adoption.html')

def denied(request,id):
    cr = adoptionnn.objects.get(id=id)
    rr='Denied'
    cr.status= rr
    e=cr.u_email 
    cr.save()
    s = smtplib.SMTP('smtp.gmail.com', 587)
    s.starttls()
    s.login("nefsal003@gmail.com", "htxalvzrrkxupspv")
    message = f' Request Accept  successfully'
    s.sendmail("nefsal003@gmail.com", e, message)
    s.quit()
    print(rr)
    mg='sent Denied msg successfully'    
    return render(request,'Adoption.html',{'msg':mg})



















# admin side



def adlogin(request):  
   if request.method=='POST':
      uname = request.POST.get('runame')
      passw = request.POST.get('rpass')
      u = 'admin'
      p = 'admin'
      if uname==u:
         if passw==p:
          return render(request,'adhome.html')
         
   return render(request,"adlogin.html")

def adhome(request):
    return render(request,"adhome.html")

def addoners(request):
   cr=user.objects.all()
   return render(request,"addoners.html",{'li':cr})    


def rmaddoners(request,id):
   cr=user.objects.get(id=id)
   cr.delete()
   return render(request,'adhome.html')

def adorphanages(request):
   cr=orphanage.objects.all()
   return render(request,"adorphanages.html",{'li':cr})    


def rmadorphanages(request,id):
   cr=orphanage.objects.get(id=id)
   cr.delete()
   return render(request,'adhome.html')

def update_status(request, id):
    if request.method == 'POST':
        status = request.POST.get('status')
        orphanage_obj = orphanage.objects.get(id=id)
        orphanage_obj.status = status
        orphanage_obj.save()
        return redirect('/adorphanages/')  # Redirect to the appropriate view after updating

    return render(request, 'adorphanages.html')

def orphans_list(request):
    orphans = orphansdetail.objects.all()
    return render(request, 'adorphansdl.html', {'orphans': orphans})

def delete_orphan(request, id):
    orphan = orphansdetail.objects.get(id=id)
    orphan.delete()
    return redirect('/orphans_list/')

def adneeds(request):
   cr=needdonation.objects.all()
   return render(request,"adneeds.html",{'donations':cr})

def rmadneeds(request,id):
   cr=needdonation.objects.get(id=id)
   cr.delete()
   return redirect('/adneeds/')