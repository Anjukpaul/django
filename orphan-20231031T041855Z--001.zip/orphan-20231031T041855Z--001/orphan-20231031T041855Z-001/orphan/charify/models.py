from django.db import models

# Create your models here.
b=(('Request Accept','Request Accept'),('Denied','Denied'))
c=(('Registration Approved','Registration Approved'),('Registration Denied','Registration Denied'))
class user(models.Model):
    fullname=models.CharField(max_length=100,null="true")
    age=models.IntegerField(null="true")
    gender=models.CharField(max_length=100,null="true")
    address=models.CharField(max_length=100,null="true")
    contact=models.IntegerField(null="true")
    email=models.EmailField(null="true")
    username=models.CharField(max_length=100,null="true")
    password=models.CharField(max_length=100,null="true")


class orphanage(models.Model):
    orphanage_id=models.CharField(max_length=50,null="true")
    orphanage_name= models.CharField(max_length=20,null="true") 
    owner_name = models.CharField(max_length=20,null="true")
    description=models.CharField(max_length=1000,null="true")
    contact=models.IntegerField(null="true") 
    email=models.EmailField(null="true")
    website=models.CharField(max_length=3000,null="true")
    category=models.CharField(max_length=20,null="true")
    bank_name = models.CharField(max_length=50,null="true")
    bank_branch=models.CharField(max_length=50,null="true")
    accno_ifsc=models.CharField(max_length=50,null="true")

    # state=models.CharField(max_length=20)
    # district=models.CharField(max_length=20)
    address=models.CharField(max_length=100,null="true") 

    year = models.IntegerField(null="true")
    image=models.ImageField(null="true")
    password=models.CharField(max_length=100,null="true")
    status=models.CharField(max_length=30,choices=c)



class orphansdetail(models.Model):
    fullname=models.CharField(max_length=20)
    orphanage_id=models.CharField(max_length=50)
    contact=models.CharField(max_length=50,null='true')
    id_number=models.IntegerField()
    image=models.ImageField(upload_to='upload/')
    age=models.IntegerField()
    gender=models.CharField(max_length=20)
    blood_group=models.CharField(max_length=20)

class needdonation(models.Model):
    orphanage_id= models.CharField(max_length=20)
    contact=models.CharField(max_length=30,null='true')
    category=models.CharField(max_length=30)
    list_item=models.CharField(max_length=30)
    quantity=models.IntegerField()
    price=models.IntegerField()
    upi_id=models.CharField(max_length=20)

class add2cart(models.Model):
    orphanage_id= models.CharField(max_length=20)
    contact=models.CharField(max_length=30,null='true')
    category=models.CharField(max_length=30)
    list_item=models.CharField(max_length=30)
    quantity=models.IntegerField()
    price=models.IntegerField()
    donatedquantity=models.IntegerField()
    amount=models.IntegerField()
    fullname=models.CharField(max_length=100,null="true")
    age=models.IntegerField(null="true")
    gender=models.CharField(max_length=100,null="true")
    address=models.CharField(max_length=100,null="true")
    contact1=models.IntegerField(null="true")
    email=models.EmailField(null="true")    

class procedpay(models.Model):
    orphanage_id= models.CharField(max_length=20)
    contact=models.CharField(max_length=30,null='true')
    category=models.CharField(max_length=30)
    list_item=models.CharField(max_length=30)
    quantity=models.IntegerField()
    price=models.IntegerField()
    amount=models.IntegerField()
    fullname=models.CharField(max_length=100,null="true")
    age=models.IntegerField(null="true")
    gender=models.CharField(max_length=100,null="true")
    address=models.CharField(max_length=100,null="true")
    contact1=models.IntegerField(null="true")
    email=models.EmailField(null="true")

class adoptionnn(models.Model):
    or_name=models.CharField(max_length=50)
    or_age=models.IntegerField()
    orphanage_id=models.IntegerField()
    or_gender=models.CharField(max_length=40)
    u_name=models.CharField(max_length=30)
    u_contact=models.IntegerField()
    u_email=models.EmailField(max_length=50)
    status=models.CharField(max_length=30,choices=b)