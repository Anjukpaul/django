from django.apps import AppConfig


class EpsappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'epsapp'
