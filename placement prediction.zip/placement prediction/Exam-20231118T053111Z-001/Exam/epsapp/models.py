from django.db import models

# Create your models here.
class userdetails(models.Model):
    name=models.CharField(max_length=28)
    email=models.CharField(max_length=30)
    phone=models.CharField(max_length=13)
    password=models.CharField(max_length=20)


