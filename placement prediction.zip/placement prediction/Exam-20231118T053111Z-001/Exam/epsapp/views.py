from django.shortcuts import render, redirect
from .models import userdetails

from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import joblib
from django.shortcuts import render


def index(request):
    return render(request, 'index.html')


def hello(request):
    return render(request, 'hello.html')



def register(request):
    if request.method == 'POST':
        uname = request.POST.get('username')
        phonenumber = request.POST.get('phonenumber')
        email = request.POST.get('email')
        passw = request.POST.get('password')

        userdetails(name=uname, phone=phonenumber, email=email, password=passw).save()
        return redirect('login')
    
    else:
        return render(request, 'register.html')

def login(request):
    if request.method=='POST':
        uname=request.POST.get('username')
        passw=request.POST.get('password')
        tr=userdetails.objects.filter(name=uname,password=passw)
        if tr:
            details=userdetails.objects.get(name=uname,password = passw)
            name=details.name
            request.session['cs']=name
            return render(request,'hello.html')
        else:
            msg='invalid username or password'
            return render(request,'login.html',{'m':msg})
    else:
        return render(request,'login.html')

def profile(request):
    u = request.session['cs']
    tr = userdetails.objects.get(name=u)
    cfname = tr.name
    cemail = tr.email
    cphone = tr.phone
    return render(request, 'profile.html', {'name': cfname, 'email': cemail, 'phone': cphone})

def predict1(request):
    if request.method == 'POST':
        # Assuming 'gender', 'ssc_p', 'ssc_b', ..., 'salary' are the form fields
        gender = float(request.POST.get('gender', 0.0))
        ssc_p = float(request.POST.get('ssc_p', 0.0))
        ssc_b = float(request.POST.get('ssc_b', 0.0))
        hsc_p = float(request.POST.get('hsc_p', 0.0))
        hsc_b = float(request.POST.get('hsc_b', 0.0))
        hsc_s = float(request.POST.get('hsc_s', 0.0))
        degree_p = float(request.POST.get('degree_p', 0.0))
        degree_t = float(request.POST.get('degree_t', 0.0))
        workex = float(request.POST.get('workex', 0.0))
        etest_p = float(request.POST.get('etest_p', 0.0))
        specialisation = float(request.POST.get('specialisation', 0.0))
        mba_p = float(request.POST.get('mba_p', 0.0))
        

        joblib_file_path = r'c:\Users\AVITA PC\Downloads\ramformodel.joblib'
        loaded_model = joblib.load(joblib_file_path)


        # Make prediction using the loaded model
        input_data = [[gender, ssc_p, ssc_b, hsc_p, hsc_b, hsc_s, degree_p, degree_t, workex, etest_p, specialisation, mba_p]]
        prediction = loaded_model.predict(input_data)[0]

        if prediction == 1:
            msg = 'Placed'
        else:
            msg = 'Not Placed'

        return render(request, 'predict.html', {'msg': msg})

    return render(request, 'predict.html')