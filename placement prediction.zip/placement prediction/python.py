l1 = [30,20,30,28]
a=len(l1)
l2 = []
for i in range(a):
    l2.insert(i,l1[-1])
    print
    l1.pop(-1)
print(l2)